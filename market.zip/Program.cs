using System;
using System.Collections.Generic;

// Main program class
public class Program
{
    // Main entry point of the program
    public static void Main()
    {
        Console.Clear();
        Console.BackgroundColor = ConsoleColor.DarkBlue;
        // Create a list of products to represent a catalog
        var inventory = new List<Product>
        {
            new ElectronicsProduct("Laptop", "Dell", 899.99),
            new SimpleProduct("Book", ProductCategory.Books, "Introduction to C# programming"),
            new ClothingProduct("T-Shirt", "Large", "Cotton"),
            new SimpleProduct("Apple", ProductCategory.Food, "Red Delicious Apple")
        };

        // Output the details of each product
        foreach (var product in inventory)
        {
            Console.WriteLine($"{product.Name} ({product.Category}): {product.GetDetails()}\n");
           
        }
    }
}