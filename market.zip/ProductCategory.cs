// Define possible product categories
public enum ProductCategory
{
    Electronics,
    Books,
    Clothing,
    Food
}