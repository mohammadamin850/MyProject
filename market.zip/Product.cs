// Abstract base class for all products
public abstract class Product
{
    // Product name and category are common properties for all products
    public string Name { get; private set; }
    public ProductCategory Category { get; private set; }

    // Constructor requires name and category for every product
    protected Product(string name, ProductCategory category)
    {
        Name = name;
        Category = category;
    }

    // Abstract method that must be implemented by derived classes to give product details
    public abstract string GetDetails();
}