// A derived class for clothing items that extends Product 
public class ClothingProduct : Product
{
    // Specialized properties for clothing items
    public string Size { get; private set; }
    public string Material { get; private set; }

    // Clothing constructor requires name, size, and material
    public ClothingProduct(string name, string size, string material)
        : base(name, ProductCategory.Clothing)
    {
        Size = size;
        Material = material;
    }

    // Overridden method to give clothing product details
    public override string GetDetails()
    {
        return $"Size: {Size}, Material: {Material}";
    }
}