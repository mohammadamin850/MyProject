// A derived class for simple products like books and food that extends Product
public class SimpleProduct : Product
{
    // Simple description for the product
    public string Description { get; private set; }

    // Constructor for simple products that only requires a description
    public SimpleProduct(string name, ProductCategory category, string description)
        : base(name, category)
    {
        Description = description;
    }

    // Overridden method to give simple product details
    public override string GetDetails()
    {
        return Description;
    }
}