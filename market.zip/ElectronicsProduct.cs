// A derived class for electronics that extends Product
public class ElectronicsProduct : Product
{
    // Specialized properties for electronics products
    public string Brand { get; private set; }
    public double Price { get; private set; }

    // Electronics constructor requires name, brand, and price
    public ElectronicsProduct(string name, string brand, double price)
        : base(name, ProductCategory.Electronics)
    {
        Brand = brand;
        Price = price;
    }

    // Overridden method to provide electronic product details
    public override string GetDetails()
    {
        return $"Brand: {Brand}, Price: ${Price}";
    }
}